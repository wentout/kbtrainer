skins["nativeprettybuttons"] = {
	  evaluator		: function(){
		skins.dbh = { // height of window
			  "paragraph"	: {
					  sml : 350
					, med : 390
					, big : 430
					, non : 220
			}
			, "native"		: {
					  sml : 280
					, med : 325
					, big : 364
					, non : 150
			}
		}
		skins.dbw = { // width of window
			  sml : 760
			, med : 760
			, big : 760
		}
		
	}
	, name			: "Native Pretty Buttons"
	, author		: "system went out"
	, link			: ""
	, mail			: "went.out@gmail.com"
}