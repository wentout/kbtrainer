//(c) 2002, Alexey Kazantsev Stamina Software Developer : http://stamina.ru
//[#]>S P E C I A L   L E S S O N S

lessons.arr.en.base3.name = "SPECIAL LESSONS";
lessons.arr.en.base3.les = new Array();

lessons.arr.en.base3.evaluator = function(){

//[#] Smiles :-)
lessons.arr.en.base3.les[0] = new Array();
lessons.arr.en.base3.les[0].name = "Smiles :-)";
lessons.arr.en.base3.les[0].str = ":) :-) ;-) :=) ;=) :o) ;o) :-/ ;-\\ B=) B-) 8-) :-P :-b :=D :-o <:-) ;^) &:-) @;-) %-) >:-( :-@ 8:-) :-{) :-{} {:-) :-7 :-9 :=] ;( :-( ;-0 :-| :( ;-( :o( ;o( ;=( B-| B-( 8=) :-)))))";

//[#] HTML
lessons.arr.en.base2.les[1] = new Array();
lessons.arr.en.base2.les[1].name = "HTML";
lessons.arr.en.base2.les[1].str = "/#/#/# #'#'#' %\"%\"\" %&%&%& _/_/_/ ;@;@;@ -:-:-: <!<!<! >=>=>= =\"#993366\" ='30%' <a href=mailto:x@y.z> <html> <head><title>Welcome</title></head> <body bgcolor=#0F0F0F leftmargin=0><p align=\"right\">Hi, people!</p> <table border=\"0\" width=76%><tr><td>&nbsp;</td></tr></table> <div align='center' width='50%'><p style=\"border:1px solid #339966\">&lt; &nbsp; &quot; &amp; &gt; </p></div> <!-- comments --> <hr width=82% color=\"#38f7e9\"><a href=\"http://staminapro.com\" target=_blank>Home</a></body></html>";

//[#] NumPad (digits only)
lessons.arr.en.base2.les[2] = new Array();
lessons.arr.en.base2.les[2].name = "NumPad (digits only)";
lessons.arr.en.base2.les[2].str = "5466¶4560¶45405¶5606¶5405¶6504¶4605¶46460¶5880¶580486¶80688¶4522¶5224¶02286¶4022¶8546¶0822¶8508¶26022¶8077¶508787¶04776¶0885¶7027¶70775¶6075¶7467¶2095¶9959¶09699¶4902¶929299¶80658¶9980¶4994¶90225¶8906¶77290¶115¶15102¶1151106¶1411¶480¶9119¶11076¶15810¶491¶851¶06842¶06789¶10461¶210¶115¶811¶7033¶5334¶603¶351¶30¶3642¶033¶5833¶031¶633031¶3130348¶609¶941387¶0564¶023203¶4602¶790¶3180¶513076¶704¶6805050¶1000¶50807¶6109¶00080¶88192¶2001¶2002¶1978¶1700¶6810¶4058¶6506¶06505¶0030¶2010¶1834¶5123¶0234¶07764¶8127¶703577¶6276¶7672¶712¶97437";

//[#] NumPad
lessons.arr.en.base2.les[3] = new Array();
lessons.arr.en.base2.les[3].name = "NumPad";
lessons.arr.en.base2.les[3].str = "7/8/9¶5/6/4¶3/1/2¶9/5/1¶87/46/32¶8*7*9¶5*6*4¶2*1*3¶7*5*3¶89*46*12¶7-9-8¶5-6-4¶3-1-2¶8-4-3¶79-65-20¶9+7+8¶5+4+6¶2+1+3¶7+6+2¶98+54+30¶7.98¶5.64¶3.12¶0.951¶3.14¶7/5*3-1+3.08¶76+84-943+80+215-30-51¶286/14*9*372/84*50/306¶.315*.486+1.509-.75/6.02¶45+5.18+862-.75-13/.94/26*3.14*80+1.27*50-6.52/9";

lessons.arr.en.base3.completed = true;
}