
layouts["native"] = {
	  name				: "Native"

	, comparsing		: "" // для того, чтобы не выводить букву в составных кнопках
	, sml_keyboardRize  : 5
	, med_keyboardRize	: 5
	, big_keyboardRize	: 5
}