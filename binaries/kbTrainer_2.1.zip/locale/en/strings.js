strings	= {
	  locale	: "en"

	, ls		: "Loading..."
	, division	: "."
	
	, s1		: " here will be pressed keys "
	, s2		: " completed through : &nbsp; "
	, s3		: " Text just starts. &nbsp;&nbsp;&nbsp;&nbsp;"
	, s4		: "Press correct key for start typing.&nbsp;&nbsp;&nbsp;"
	, s5		: " [Shift + F1] for help."
	, s6		: "PAUSE.&nbsp;&nbsp;&nbsp; press &nbsp;&nbsp;\"_Space_\""
	, s7		: "Text Over! Position mooved to start. <br>Press bar to start typing it again."

	, s7_1		: "Incalculable error, there is no letters in lesson..."
	, s7_2		: "Incalculable error, there is no letters in book..."
	, s7_3		: "Incalculable error, there is no letters in vocabulary..."

	, s8		: " Initiations, please Wait ...  "
	, s9		: "There is no books in YOUR library."
	, s10		: "There is no books in library.<br>Use lessons mode [F4].<br>Or add book to the lib by [F8]."

//	, s11 		: "reserved"

	, s12		: "Typing Config : "
	, s13		: ""
	, s14		: "there is no books, add book by [F8]"

	, s15		: "\"Default book\" deleted. Select book [F4]."

	, s16		: "Here so on, try to make personalisations..."
	, s17		: "Mode"
	, s18		: "lessons"
	, s19		: "books"
	, s20		: "#"
	, s21		: "Error Control"
	, s22		: "To Enlight Shift Key"
	, s23		: "Skin :"
	, s24		: "Layouts :"
	, s25		: "Keyboards :"

	, s26		: "Main Settings"
	, s27		: "History"
	, s28		: "Skins"
	, s29		: "Keyboard"

	, s30		: " Current lesson ends. <br>Select another lesson press bar to type it again."

	, s31		: "One Error Only!"
	, s32		: "Count errors always"
	, s33		: "Enlight Space to another hand"
	, s34		: "Space enlighting dependent from shift"

	, s35		: "Show keyboard"
	, s36		: "Hide keyboard "
	, s37		: " when typing speed over : "
	, s38		: " Change layout by pressing"

	, s39		: "Keyboard Size :"
	, s40		: "Big"
	, s41		: "Medium"
	, s42		: "Small"
	, s43		: "Wait Please!!!"
	, s44		: " Keyboard params "
	, s45		: " simple "
	, s46		: " this "
	, s47		: " or this "
	, s48		: " Histiry is Empty! "

	, s49		: "Skip non typable characters "


	, s50		: " Sound "

	, s51		: " plays "
	, s52		: " volume"

	, s53		: "In the same way \"F2\" always forse layout to change. <br>E.g. i've had some trouble on *Nix platform, so...\
<br>Etc. in FF I can't find any decision for Caps Lock..."

	, n1		: ["&lt;&lt;&lt;&nbsp;&nbsp;&nbsp; ", " &nbsp;&nbsp;&nbsp;&gt;&gt;&gt;", "Typing speed : "]
	, n2		: ["err % : ", "Error Percent : "]
	, n3		: "Symbols typed : "
	, n4		: "Err typed : "
	, n5		: ["txt % : ", "Text position : "]
	, n6		: "Right Shift"
	, n7		: "Pressed : "
	, n8		: "Left Shift"
	, n9		: "You typing about : "
	, nt		: ["hh", "mm", "ss"]

	, m1		: "+++"
	, m2		: "Shift + F1 : help"
	, m3		: "F2 : lang"
	, m4		: "F3 : type"
	, m5		: "F4 : mode"

	, m7		: "F5 : set'n's cfg"
	, m8		: "F8 : library"


	, l0		: "Message : <br><br>"
	, l0_0		: "Here will be displayed Sample of selected Text <br> or other Informational Messeges."
	, l1		: "Library (Ctrl + L)"
	, l2		: "To Add a Book (Ctrl + A)"
	, l3		: "File sucsessfuly saved!"
	, l4		: "To Save book select a file first!"
	, l4_1		: "please try to Select Another File"
	, l5		: "Saving... Please WAIT!"
	, setAds	: "Ctrl+O - Open File. Tab for navigation between dialog elements. Mouse supported to :)"
	, libFiles	: "\"Arrow Keys\" - navigation. Enter or \"space\" - selection. Ctrl+D - delete book. Mouse supported to :)"
	, l6		: "About to delete book : "
	, l7		: "Deleting! Please, WAIT... ... ..."
	, l8		: "You can't delete active book! \nSelect another, then delete this!"
	, l9		: "Include word wrap in  text: : ( &crarr; &nbsp;+&nbsp; ! ? . : ) ."
	, l9_1		: "All wrapping !"
	, l10		: "path"
	, l11		: "autor"
	, l12		: "book"
}