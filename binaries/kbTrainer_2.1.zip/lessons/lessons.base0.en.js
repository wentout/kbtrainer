//[#]>B A S I C   L E S S O N S
//(c) 2002, Alexey Kazantsev Stamina Software Developer : http://stamina.ru

lessons.arr.en.base0.name = "BASIC LESSONS";
lessons.arr.en.base0.les = new Array();

lessons.arr.en.base0.evaluator = function(){

//[#] df  jk
lessons.arr.en.base0.les[0] = new Array();
lessons.arr.en.base0.les[0].name = "df  jk";
lessons.arr.en.base0.les[0].str = "fffjjj ffjfj jffjj fjfjf jjfjf fj fjf fjffj jfjfj jf jfj dddjjj ddjdj jddjj djdjd jjdjd dj df jd djddj jdjdj dj dfd fd jd jfd jdf kkkddd kkdkd dkkdd kdkdk ddkdk kf jdk kj kdkkd dkdkd kj dk jdk fkjd ffkfk kffkk fkfkf kf jfk kkfkf fkffk kfkfk fk fdk fkj dfk ddfdf fddff kf dfd ffdfd jd fdd fkd jjkjk kjjkk jk jdk jkjkj kj fkj djdfk jfkkd jdjkf fjddk fkfdj kdjjf kfkjd dkffj dj fdd jk dfd jdk jd kf djfk";

//[#] as  l;
lessons.arr.en.base0.les[1] = new Array();
lessons.arr.en.base0.les[1].name = "as  l;";
lessons.arr.en.base0.les[1].str = "ssslll sslsl lssll slsls llsls sl ls lsl slssl lslsl lf kl lsd sk sf sl fls dll jl js aaalll aalal laall alala llala la lak all alaal lalal ad adj lda alf alfa sal flak ;;;aaa ;;a;a a;;aa ;a;a; aa;a; ala; dak; kaka; ;a;;a a;a;a add jaffa; da aka dad; ss;s; ;ss;; s;s;s ;;s;s fss; js; s;ss; ;s;s; ass; lass; aasas saass ask sla asasa ssasa jsa sad sas ll;l; ;ll;; fl; l;l;l ;;l;l fla; fld; alas; ls;;a lal;s slaa; s;sal ;alls ;s;la a;ssl als fall dak das jad; adsl; skald; alk flask; falls adds fad; lass asks lad; sad dad ass as a flak;";

//[#] vb  nm
lessons.arr.en.base0.les[2] = new Array();
lessons.arr.en.base0.les[2].name = "vb  nm";
lessons.arr.en.base0.les[2].str = "bbbnnn bbnbn nbbnn bnbnb nnbnb nan bab blab lan ban jan bnbbn nbnbn abba anna jab nab bass bask bad fan lab fab dab nb dan bland blank and bank vvvnnn vvnvn nvvnn vnvnv nnvnv val van vnvvn nvnvn java vs vb vandal vas vj lava naval dvd mmmvvv mmvmv vmmvv mvmvm vvmvm mak malm mvmmv vmvmv am lam mass mamma small mask jam sms jvm bbmbm mbbmm bmbmb mmbmb amb lamb bmbbm mbmbm bam jamb mamba vvbvb bvvbb vbvbv bvds vnnmnm mnnmm man mmnmn manna nam vnvbm nbmmv nvnmb bnvvm bmbvn mvnnb mbmnv vmbbn band van kvass lambda dvd nan jams small bank vandal";

//[#] tg  yh
lessons.arr.en.base0.les[3] = new Array();
lessons.arr.en.base0.les[3].name = "tg  yh";
lessons.arr.en.base0.les[3].str = "tttyyy ttyty yttyy tytyt yytyt my tad tytty ytyty talk fat yak sat mat nat yam yd nasty navy tasty may tatty lastly gggyyy ggygy yggyy gygyg yygyg baggy gyggy ygygy gad slang lag jaggy gadfly mangy gabby hhhggg hhghg ghhgg hghgh gghgh hash ghat hghhg ghghg has handy dash aghast tthth htthh ththt hhtht that bath thtth hthth thank myth ggtgt tggtt gat gtgtg ttgtg tang yyhyh hyyhh shy yhyhy hhyhy hymn gygth ythhg ygyht tyggh thtgy hgyyt hthyg ghtty gyttja ghastly shaggy laystall fatly tansy gym lay by taffy sly yank tat many thanks";

//[#] er  ui
lessons.arr.en.base0.les[4] = new Array();
lessons.arr.en.base0.les[4].name = "er  ui";
lessons.arr.en.base0.les[4].str = "rrruuu rruru urruu rurur uurur radar ugly rug rurru ururu rub rural aura drum jury burn hurry guru ruth eeeuuu eeueu ueeuu eueue uueue sun eye vugh bevel gun eueeu ueueu leu lues neutral hue due fuel rueful guest heugh iiieee iieie eiiee ieiei eeiei evil fire ieiie eieie tie lie die tried ivied field reign rriri irrii ririr iirir irk sir rirri iriri iris trim bird rile girl firm eerer reerr there erere rrere here nerve uuiui iuuii suit guide uiuiu iiuiu build ruins eueri uriie ueuir rueei rireu ieuur iriue eirru vigil duke merit germinative guerilla mute university gurgle true rule during survey remain renumber";

//[#] qw  op
lessons.arr.en.base0.les[5] = new Array();
lessons.arr.en.base0.les[5].name = "qw  op";
lessons.arr.en.base0.les[5].str = "wwwooo wwowo owwoo wowow oowow wow low now owe woe wowwo owowo row owner wood woke worm wolf world how work qqqooo qqoqo oqqoo qoqoq ooqoq qua iq qoqqo oqoqo equal quad quake quiet quit unique queen quay quod quoin quorum quota quotha pppqqq ppqpq qppqq pqpqp qqpqp equip up pqppq qpqpq pal pig pen pan pap pepper pepsi rap vip tape pair palp opaque wwpwp pwwpp wpwpw ppwpw paw pow wpwwp pwpwp wrap wipe weep whip wimp qqwqw wqqww sow qwqwq wwqwq query oopop poopp pop opopo ppopo opel prop qoqwp owppq oqopw woqqp wpwqo pqoow pwpoq qpwwo quid pro quo equator whore purple equivoke whole power opaque";

//[#] xc  , .
lessons.arr.en.base0.les[6] = new Array();
lessons.arr.en.base0.les[6].name = "xc  , .";
lessons.arr.en.base0.les[6].str = "ccc,,, cc,c, ,cc,, c,c,c ,,c,c cd, cop, cow, calc, c,cc, ,c,c, cap, cup, cut, copy, cake, come, accept, cock, clock, cache, cackle, cluck, clinic, click cancel xxx,,, xx,x, ,xx,, x,x,x ,,x,x xxl, xml, mix, six, x,xx, ,x,x, fax, fox, box, vox, dux, excel, onyx, exile ...xxx ..x.x x..xx .x.x. xx.x. lex. cox. .x..x x.x.x xmas. xerox. oxy. extreme. exact, relax, cc.c. .cc.. c.c.c ..c.c .ca .ch .com c.cc. .c.c. ch. ck. civ. con. xxcxc cxxcc calyx xcxcx ccxcx coax coccyx ,,.,. .,,.. ex., ,.,., ..,., etc., x,xc. ,c..x ,x,.c c,xx. c.cx, .x,,c .c.,x x.cc, p.c., i.e., e.g., www.pix.com, a.m., unix.com, xxx.com";

//[#] z ! ? /
lessons.arr.en.base0.les[7] = new Array();
lessons.arr.en.base0.les[7].name = "z ! ? /";
lessons.arr.en.base0.les[7].str = "zzz/// zz/z/ /zz// z/z/z //z/z jazz zoo/zone z/zz/ /z/z/ zero zap/zombie mezzo lazy/hazy gaze zoom/gizmo, crazy zigzag/puzzle !!!/// !!/!/ /!!// !/!/! //!/! hello/hi! go! !/!!/ /!/!/ welcome! thanks! bazooka! squeeze! ???!!! ??!?! !??!! ?!?!? !!?!? how?! who? ?!??! !?!?! toxic!? why? azure? ok! zz?z? ?zz?? z?z?z ??z?z oz? fuzzy zebra? z?zz? ?z?z? zeal? zinc? !!z!z z!!zz zip! !z!z! zz!z! zing! //?/? ?//?? yes/no? /?/?/ ??/?/ zephyr/pizza? !/!z? /z??! /!/?z z/!!? z?z!/ ?!//z ?z?/! !?zz/ zenith/frozen waltz tzar/lizzie pkunzip.zip? new! all right! what? which? are you here? good luck/bye!";

//[#] Alphabetic test
lessons.arr.en.base0.les[8] = new Array();
lessons.arr.en.base0.les[8].name = "Alphabetic test";
lessons.arr.en.base0.les[8].str = "fall jam dash kid ska lad alf bank navy valid man gal ham talk yak rutty urn elf is wolf oven quasi pet xxl cot zone abcdefghijklmnopqrstuvwxyz fife jojoba doddle kick suss label aka bob nine vulva memo guggle hah totality yellowy river unused eke ivied willow oboe quark prep xerox clack zigzag zyxwvutsrqponmlkjihgfedcba";

//[#] Short words
lessons.arr.en.base0.les[9] = new Array();
lessons.arr.en.base0.les[9].name = "Short words";
lessons.arr.en.base0.les[9].str = "hay heir harp half hang hack hex high echo earn elan eddy edit obit oboe obey owl oak okie dokey down duty dux dixy doxy xmas xtal nix next note name nape nail snap spar step slow shot shit qua quay quad quod quit pack pray pure pig pixy push rush rue rock rose rich ring main mad male melt milk make zero zest zonk zoom zinc zing year yelp ywis your chip char cut chut coxy cow kale ken knap keep keck kiwi with wind wick woke wont void volt vole vote vita vox vug very jerk joke jack jab job jamb jeep girl glue gold grow good luck lake lid lie lex live love";

//[#] Long words
lessons.arr.en.base0.les[10] = new Array();
lessons.arr.en.base0.les[10].name = "Long words";
lessons.arr.en.base0.les[10].str = "allowable absolute black bonus bicycle expressive eating fortune finish frequency fuzzy imperial include kilobyte obtain throw tutor cherry casino cinema cajole candle rubric rover rigor unbound unique vampire velvet vogue yearly zombie zippy quack quick quake queen query quorum quadruple xenon xerox xistor xiphoid xylogen xanthoxylone nixie nothing network neighbour window weight world winch whose white south sounding submarine jumbo justify journey government paradox penalty paving pepsi guano apes memento mori";

//[#] CAPITAL letters
lessons.arr.en.base0.les[11] = new Array();
lessons.arr.en.base0.les[11].name = "CAPITAL letters";
lessons.arr.en.base0.les[11].str = "Fred Fuji Jerry January Dick Doom Kate Ken Sony Stamina Lily Lady April Alf Nick NB Victor Val Bob Bill Yes YOB Tom Tim Henry Hamlet Grace Glen Uncle Unreal Romeo RIP Irene ICQ Eve Earth Mylene MIB Chris Charles Oval Office Walt Wales Peg PS Quake Queen Xmas XXL Zaire Zorro Felix John December Kit Sam Luke Alex November VIP Boston Yahoo Ted Helen Gates UFO Rose Ira Ed May Carol October WC Pol Quantum XML Zanzibar Antonio Vivaldi Nino Rota Bon Jovi Led Zeppelin Pink Floyd Genesis Vaya Con Dios Enya";

//[#] ' " ( )
lessons.arr.en.base0.les[12] = new Array();
lessons.arr.en.base0.les[12].name = "' \" ( )";
lessons.arr.en.base0.les[12].str = "((())) (()() )(()) ()()( ))()( a) b) c) (home) ()(() )()() (Time), (mix), (Drill), (go) '''))) '')') )'')) ')')' ))')' I'm, it's (Don't) ')'') )')') isn't Can't (Father's) I'll \"\"\"''' \"\"'\"' '\"\"'' \"Hi!\" \"I'm hungry\" \"'\"'\" ''\"'\" \"Won't\", \"hasn't\", \"It's no good\", \"Bye\" ((\"(\" \"((\"\" (\"(\"( \"\"(\"( (\"Ball\"), (\"Tie\") (\"((\" \"(\"(\" (\"Cow\"), (\"Wake up\"), (\"Fine\") ''('( (''(( (hasn't) '('(' (('(' (Doesn't) ))\")\" \"))\"\" (\"Disk\") \")\") \"\")\") (\"Rome\") ')'(\" )(\"\"' )')\"( ()''\" (\"(') \"'))( \"(\")' '\"(() \"I'll be back\", (\"Don't cry\"), \"L'Instant X\".";

//[#] ; : -
lessons.arr.en.base0.les[13] = new Array();
lessons.arr.en.base0.les[13].name = "; : -";
lessons.arr.en.base0.les[13].str = ";;;::: ;;:;: :;;:: ;:;:; ::;:; a:b; c:d; ;:;;: :;:;: City: Color: Password: ;) :) e; f; g; ;;;--- ;;-;- -;;-- ;-;-; --;-; so-so; back-up; ;-;;- -;-;- about-face; yo-yo; hara-kiri ;-) ::-:- -::-- :-:-: --:-: chin-chin :) :-::- -:-:- fie-fie: you-know-what :-) ;;:-; :;-:: -;--: ping-pong ;-:;: ;-:-; -:-;: month: June; ;:-:;- ;-:-;: :-;-:; Coca-cola; name: Alice; hobby: music; etc; case: break; continue; Bye-bye";

//[#] Sentences with '
lessons.arr.en.base0.les[14] = new Array();
lessons.arr.en.base0.les[14].name = "Sentences with '";
lessons.arr.en.base0.les[14].str = "I'm sorry I'm late. You'll see. What's she like? It's all right! I'll call back later. Don't hang up. You don't understand me. No, I haven't. I'm in a hurry! They'll take this. What's wrong? I'm tired. Don't come in. Peter's friend. O'Henry. He doesn't like it. I'm lost. These men's plans. Don't cry. The cat's tail. No, she hasn't. I can't be with you. Don't speak. It's no good. What's my age again? Let's go!";

//[#] Punctuation marks
lessons.arr.en.base0.les[15] = new Array();
lessons.arr.en.base0.les[15].name = "Punctuation marks";
lessons.arr.en.base0.les[15].str = "It's hasn't; I'll, They're wasn't. couldn't. \"What's it?\", \"Brian's brain\"; \"I'm sorry!\" :o)) ;) :o(( acc. (\"account\"); It's (It is); ex. (\"example\"); :)) :-) ;-( and/or yes/no - OK/Cancel :-) http://x.y.z/files/ How are you? \"Good-bye!\" Month/Day/Year; \"I've been robbed!\" :-( Really?";

//[#] Examination
lessons.arr.en.base0.les[16] = new Array();
lessons.arr.en.base0.les[16].name = "Examination";
lessons.arr.en.base0.les[16].str = "Don't hurry! Fifth/fief/Forfend, Joe? jar? Jojoba? Dad! dud! Doom! (Kick) (kink) (Kodak). So-so - suss - Sister, Level; label; Lola; Abandon: abaca: Anna: 'Viva', 'valve', 'Volvo'. \"Nanny\", \"noun\", \"Nine\". Bubble/barber/Bob. Yearly? yummy? You? That - totter - Tit - (High) (hash) (Hatch). Gag! giggle! Gong! Uruguay; usual; Usurp; River: rural: Roper: 'Icing', 'iris', 'IQ'. \"Eye\", \"elite\", \"Eden\". Mam/mummy/Mem. Cicero? cocky? Clock? October - oppose - Oboe - (Wow) (withdraw) (Windows). Pappy! pup! Pipe! Quit; qual; Quake; Xerxes: xerox: Xmas: 'Zanzibar', \"zigzag\", 'Zoo'. If you didn't look at the keyboard while typing, you can try working in the Phrase Mode! Regards.";

lessons.arr.en.base0.completed = true;
}