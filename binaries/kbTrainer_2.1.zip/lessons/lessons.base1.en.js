//(c) 2002, Alexey Kazantsev Stamina Software Developer : http://stamina.ru
//[#]>C O M B I N A T I O N S

lessons.arr.en.base1.name = "COMBINATIONS";
lessons.arr.en.base1.les = new Array();

lessons.arr.en.base1.evaluator = function(){

//[#] Combinations 1
lessons.arr.en.base1.les[0] = new Array();
lessons.arr.en.base1.les[0].name = "Combinations 1";
lessons.arr.en.base1.les[0].str = "th the they then them there their that this wh why who whom when where what while ea eat east tear read head beat deal leaf ed bed med led red tired shed liked armed moved en pen den ten often listen given taken even frozen happen broken er her ever over river after enter under order biker joker ar car bar mar oral polar solar star or for nor author actor major motor tutor sailor al pal gal dual usual rural royal vital total ay say day way ray pay lay may ly sly fly ugly only rally reply apply badly ry try cry dry fry very weary carry gh high sigh weigh bough though ew new few pew blew view ow now how low row sow yellow";

//[#] Combinations 2
lessons.arr.en.base1.les[1] = new Array();
lessons.arr.en.base1.les[1].name = "Combinations 2";
lessons.arr.en.base1.les[1].str = "un un un un un un unit uncle under unable unlock ing ing ing ing ing ing ping wing bring thing doing going ght ght ght ght ght ght night right weight straight thought ish ish ish ish ish dish wish finish publish longish ist ist ist ist ist ist fist list exist consist ous ous ous ous ous ous nous famous nervous house age age age age age age page stage manage voyage Garbage ant ant ant ant ant ant rant distant giant variant ment ment ment ment ment ment moment ferment equipment tion tion tion tion tion tion action option edition mention condition citation ture ture ture ture ture ture future culture nature picture";

//[#] Parts of speech 1
lessons.arr.en.base1.les[2] = new Array();
lessons.arr.en.base1.les[2].name = "Parts of speech 1";
lessons.arr.en.base1.les[2].str = "the the the the they they they they they they there there there there there there at at at at that that that that that that what what what what what what is is is is his his his his his his this this this this this this it it it it in in in in to to to to into into into into into into an an an an can can can can can can and and and and and and as as as as was was was was was was has has has has has has had had had had had had have have have have have have be be be be been been been been been been up up up up on on on on upon upon upon upon upon upon upon if if if if of of of or or or or for for for for for for from from from from from from who who who who who why why why why why which which which which which which which which which which we we we we were were were were were were are are are are are are";

//[#] Parts of speech 2
lessons.arr.en.base1.les[3] = new Array();
lessons.arr.en.base1.les[3].name = "Parts of speech 2";
lessons.arr.en.base1.les[3].str = "isn't isn't isn't isn't aren't aren't aren't aren't can't can't can't can't wasn't wasn't wasn't wasn't weren't weren't weren't weren't haven't haven't haven't haven't hasn't hasn't hasn't hasn't hadn't hadn't hadn't hadn't won't won't won't won't don't don't don't don't didn't didn't didn't didn't This's This's This's This's They're They're They're They're You're You're You're You're It's It's It's It's I'm I'm I'm I'm I'll I'll I'll I'll What's What's What's What's";

lessons.arr.en.base1.completed = true;
}