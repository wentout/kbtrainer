skins["native_r9"] = {
	  evaluator		: function(){
		skins.dbh = { // height of window
			  "paragraph"	: {
					  sml : 430
					, med : 470
					, big : 510
					, non : 300
			}
			, "native"		: {
					  sml : 280
					, med : 325
					, big : 364
					, non : 150
			}
		}
		skins.dbw = { // width of window
			  sml : 760
			, med : 760
			, big : 760
		}
		vars.num_of_rows = 9;
		vars.view_wh_pos = 6;
	}
	, name			: "Native 9 rows Skin"
	, author		: "system went out"
	, link			: ""
	, mail			: "went.out@gmail.com"
}