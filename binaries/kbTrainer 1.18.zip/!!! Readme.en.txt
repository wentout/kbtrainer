LICENSE:

ALL this you can use by GNU GPL. 

And, so main things from there for you:
This "software" distributes in open sourses.
You use this "software" by your own risk.
NOTHING MY RESPONSIBILITY, IN ANY CASES!!!
All damage, you may have using this "software" -- originate by your own fault.
Because you may afraid, but you don't do!

But all right on sourses, that wrotten by me, 
belong exceptionally to me. &copy; went.out@gmail.com


Commercial use of this "software" or it's sourses is not prohibited.

LEFT:
Just start kb.hta. F1 - help. 
Oh... you need to generate login and password by your own mind. ;^)